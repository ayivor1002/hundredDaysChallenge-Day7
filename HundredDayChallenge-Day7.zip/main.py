import random
from hangman_art import *
from replit import clear
from hangman_word import word_list

#affichage du logo
print(logo)

#choix aleatoire d'un mot parmis la liste des mots
chosen_word = (random.choice(word_list)).lower()
#test
#print(f"Le mot choisi:{chosen_word}")


#initialisation du nombre de vies a 7
lives=7

#declaration d'un tableau vide
display = []

#parcours des lettres du mot et ajout d'un _ a chaque lettre trouvé
for letter in chosen_word:
  display.append("_")

#affichage du tableau sous forme de string
print(f"{' '.join(display)} \n")

#initialisation de la variable qui va gerer le fin du jeu a false
end_game=False

#tant que ce n'est pa la fin du jeu...
while not end_game:
  #demander a l'utilisateur de saisir une lettre
  guess = (input("Donnez une lettre: ")).lower()
  #desencombrage du terminal
  clear()
  #print(guess)


  #verification du l'existence de cette lettre dans la liste
  if guess in display:
    #affichage de rappel à l'utilisateur
    print("Vous avez deja trouvé cette lettre")

  #pour chaque entier se situant dans l'intervalle 0-tailleDuMotChoisi-1...
  for i in range(0, len(chosen_word)):
    #si la lettre saisie par l'utilisateur est retrouvée parmis les lettres du mot choisi... 
    if guess == chosen_word[i]:
      #remplacer le _ a cette position par la lettre en question 
      display[i] = guess
  #afficher la liste sous forme chaine de caractere    
  print(f"{' '.join(display)} \n")

  #si la saisie n'est pas retrovée parmis les lettres du mot..
  if guess not in chosen_word:
    #affichage un message a l'utilisateur
    print(f"{guess} ne fait pas partie des lettres du mot.")
    #decremeter le nombre de vie 
    lives-=1
    #affectation du schema correspondant au nombre de vie du joueur a la variable vie_rest
    vie_rest=hangman[lives]
    #affichage du schema
    print(vie_rest)
    #affichage d'un msg au joueur l'informant du nombre de vies restants
    print(f"Vous avez perdu une vie. Il vous en reste {lives}")
    
    #on verifie si le nombre de vie a atteint 0
    if lives==0:
      #si oui, afficher a l'utilisateur qu'il a perdu et lui afficher du mot a trouver
      print(f"Vous avez perdu, le mot recherché etait: {chosen_word}")
      #changement de la valeur de la variable end_game à True
      end_game=True      

  #Si on ne retrouve plus "_" dans le liste...
  if "_" not in display:
    #fin du jeu
    end_game=True
    #affichage a l'utilisateur un message l'informant qu'il a gagné
    print('Vous avez gagné !!')
